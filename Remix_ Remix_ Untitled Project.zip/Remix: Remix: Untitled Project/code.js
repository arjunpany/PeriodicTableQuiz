var id = getColumn("Periodic Table Elements", "id");
var name = getColumn("Periodic Table Elements", "Name");
var shortname = getColumn("Periodic Table Elements", "Symbol");
var tracker = 0;
var guessLetter;
var counter = 0;

onEvent("random", "click", function( ) {
  something();
});
onEvent("answer", "click", function( ) {
  check();
});
onEvent("button1", "click", function( ) {
  var elementText;
  setScreen("screen2");
  for (var i = 0; i < name.length-1; i++) {
    elementText = elementText + ("\n" + shortname[i]) + " = " + name[i];
  }
  setText("text_area3", elementText);
});
onEvent("button2", "click", function( ) {
  setScreen("screen1");
});

function something() {
  var index = randomNumber(1, id.length-1);
  for (var i = 0; i < name.length-1; i++) {
    tracker = name[index];
    setProperty("text_input1", "text", shortname[index]);
    if (id[i]==index) {
      return something;
    }
  }
}
function check() {
  guessLetter = getText("text_input2");
  if (guessLetter == tracker) {
    setProperty("text_area1", "text", "Correct");
    counter = counter + 1;
    setText("text_input3", counter);
  } else {
    setProperty("text_area1", "text", "Wrong");
  }
}
